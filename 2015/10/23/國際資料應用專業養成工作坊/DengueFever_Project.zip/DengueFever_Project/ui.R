library(shiny)
library(leaflet)
# Define UI for application that draws a histogram
shinyUI(fluidPage(
  
  # Application title
  titlePanel("登革熱發病與噴藥!"),
  
  # Sidebar with a slider input for the number of bins
  sidebarLayout(
    sidebarPanel(
      
      # 發病數Label
      h3(textOutput("sickLabel"), style = "color: #FF0000;"),
      # 灑藥日期Label
      h3(textOutput("sprayDateLabel"), style = "color: #4CAF50;"),
      
      # ==========================================
      # 地圖
      # 1.灑藥日期的選擇
      dateInput("sprayDate", label = h3("選擇灑藥日期"), value = "2015-10-20", 
                min = "2015-10-01", max = "2015-10-20", 
                format = "yyyy-mm-dd", 
                language = "zh-TW"),
      # 2.灑藥起始日的天數內發病資料選擇
      sliderInput("afterSprayDay", label = h3("灑藥起始日的天數內發病"), min = -7, max = 7, value = 0),
      
      
      hr(),
      
      
      
      # ==========================================
      # 選地區
      selectInput("area", label = h3("選擇地區"), 
                  choices = areaList, 
                  selected = "全部")
      # 長條圖(噴藥次數＋發病數)
      # 縱軸 => 數量
      # 橫軸 => 日期
      
#       hr(),
#       # ==========================================
#       # 選月份
#       selectInput("select", label = h3("選月份"), 
#                   choices = list("Choice 1" = 1, "Choice 2" = 2, "Choice 3" = 3), 
#                   selected = 1)
#       # 縱軸 => 數量
#       # 橫軸 => 地區
    ),

    mainPanel(
      leafletOutput("map",height = 800)
      
    )
  )
))
