library(leaflet)
library(dplyr)

shinyServer(
  
  function(input, output) {
    
    sickCount <- 0
    
  
    output$map <- renderLeaflet({
      
      #篩選出指定的噴藥日期的噴藥地點資料
      filterSprayDataSet <- filter(spraySubset, Date == input$sprayDate )
      
      
      #篩選出已噴藥幾天內發病的資料
      ifelse(as.integer(input$afterSprayDay) >= 0 ,
             dateRange <- seq(from = input$sprayDate , to = input$sprayDate + as.integer(input$afterSprayDay), by = 1),
             dateRange <- seq(from = input$sprayDate , to = input$sprayDate + as.integer(input$afterSprayDay), by = -1)
      )
      filterSickDataSet <- filter(sickSubset, Date %in%  dateRange) 
      
      sickCount  <<- nrow(filterSickDataSet)
      
      listAll <- rbind(filterSprayDataSet, filterSickDataSet)
    
      #篩選出地區
      if(as.character(input$area) != "全部")
             listAll <- filter(listAll, Distn == input$area )
            

      
      # leaflet Circle顏色的設定
      pal <- colorFactor(c("red", "green"), domain = c("sick", "spray"))
      
      # leaflet 設定
      m <- leaflet(data=listAll) %>% addTiles() %>%
        setView(lng = 120.22, lat = 22.988, zoom = 13) %>%
        
        addCircleMarkers(
          lng = ~lng,
          lat = ~lat,
          radius = ~ifelse(flag == "sick", 6, 10),
          color = ~pal(flag),
          stroke = TRUE, fillOpacity = 0.5
        )
      m

    })
    
    
    output$sprayDateLabel <- renderText({
      paste0(paste0("綠色:於", input$sprayDate), "灑藥")
    })
    
    output$sickLabel <- renderText({
      # 為了讓畫面更新
      input$afterSprayDay
      input$sprayDate
      
      paste0(paste0("紅色：共", sickCount), "例確診")
    })
    

})
