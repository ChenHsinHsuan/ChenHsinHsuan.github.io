library(shiny)

#抓取噴藥場次
sprayList <- read.csv('data/10410.csv', stringsAsFactors = FALSE)
#取日期,區域,里別,經緯度 的欄位資料
spraySubset=sprayList[,c(5, 3, 4, 14, 15)]
spraySubset$flag = 'spray'
colnames(spraySubset) <- c("Date", "Distn", "vill", "lng","lat", "flag")
#日期的轉換
spraySubset$Date <- sub("月", "-", spraySubset$Date)
spraySubset$Date <- sub("日", "", spraySubset$Date)
spraySubset$Date <- as.Date.character(paste0("2015-", spraySubset$Date), formate="%y-%m-%d")
#清除空白
spraySubset$Distn <- gsub("　", "",spraySubset$Distn)



#抓取10/10號的確診病例
sickList <- read.csv('data/sickList/1001.csv', stringsAsFactors = FALSE) %>% 
  rbind(read.csv('data/sickList/1002.csv', stringsAsFactors = FALSE)) %>% 
  rbind(read.csv('data/sickList/1003.csv', stringsAsFactors = FALSE)) %>% 
  rbind(read.csv('data/sickList/1004.csv', stringsAsFactors = FALSE)) %>% 
  # rbind(read.csv('data/sickList/1005.csv', stringsAsFactors = FALSE)) %>% 
  rbind(read.csv('data/sickList/1006.csv', stringsAsFactors = FALSE)) %>% 
  rbind(read.csv('data/sickList/1007.csv', stringsAsFactors = FALSE)) %>% 
  rbind(read.csv('data/sickList/1008.csv', stringsAsFactors = FALSE)) %>% 
  rbind(read.csv('data/sickList/1009.csv', stringsAsFactors = FALSE)) %>% 
  rbind(read.csv('data/sickList/1010.csv', stringsAsFactors = FALSE)) %>% 
  rbind(read.csv('data/sickList/1011.csv', stringsAsFactors = FALSE)) %>% 
  rbind(read.csv('data/sickList/1012.csv', stringsAsFactors = FALSE)) %>% 
  rbind(read.csv('data/sickList/1013.csv', stringsAsFactors = FALSE)) %>% 
  rbind(read.csv('data/sickList/1014.csv', stringsAsFactors = FALSE)) %>% 
  # rbind(read.csv('data/sickList/1015.csv', stringsAsFactors = FALSE)) %>% 
  rbind(read.csv('data/sickList/1016.csv', stringsAsFactors = FALSE)) %>% 
  rbind(read.csv('data/sickList/1017.csv', stringsAsFactors = FALSE)) %>% 
  rbind(read.csv('data/sickList/1018.csv', stringsAsFactors = FALSE)) %>% 
  rbind(read.csv('data/sickList/1019.csv', stringsAsFactors = FALSE)) %>% 
  rbind(read.csv('data/sickList/1020.csv', stringsAsFactors = FALSE))

#取日期,區域,里別,經緯度 的欄位資料
sickSubset = sickList[,c(1, 2, 3, 6, 5)]
# 別名動作
sickSubset$flag = 'sick'
colnames(sickSubset) <- c("Date", "Distn", "vill", "lng","lat", "flag")
#日期的轉換
sickSubset$Date <- as.Date.character(sickSubset$Date, formate="%y/%m/%d")
#清除空白
sickSubset$Distn <- gsub("　", "", sickSubset$Distn)


# 合併 spraySubset 和  sickSubset
allList <- rbind(spraySubset, sickSubset)



areaList <- as.list( unique(allList$Distn) )
areaList <- c(全部 = "全部", areaList)
#    Key             Value
names(areaList) <- unlist(areaList)


