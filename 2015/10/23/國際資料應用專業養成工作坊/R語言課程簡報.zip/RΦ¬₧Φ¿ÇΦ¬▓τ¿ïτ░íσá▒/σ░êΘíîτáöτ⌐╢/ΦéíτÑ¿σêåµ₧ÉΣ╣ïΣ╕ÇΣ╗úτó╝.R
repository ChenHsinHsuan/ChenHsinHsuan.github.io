install.packages("quantmod")
library(quantmod)

args(getSymbols)
getSymbols("AAPL") ## get the data from Yahoo Finance
head(AAPL, 3)
class(AAPL)

getSymbols('CPIAUCNS',src='FRED')
head(CPIAUCNS)

getDividends("CHL")->CHL.div
head(CHL.div)

getSplits("MSFT")->MSFT.spl
head(MSFT.spl)

AAPL.OPT <- getOptionChain("AAPL")
head(AAPL.OPT$calls, n=2)
head(AAPL.OPT$puts, n=2)

getMetals("gold",from="2014-01-01")
head(XAUUSD)

getFX("USD/EUR")
head(USDEUR)
tail(USDEUR)

getFX("USD/NTD")
tail(USDNTD)

getFX("NTD/USD")
tail(NTDUSD)

getFin('AAPL') # returns AAPL.f to "env"
viewFin(AAPL.f, "IS", "Q")  # Quarterly Income Statement
viewFin(AAPL.f, "CF", "A")   # Annual Cash Flows

getSymbols("AAPL")
barChart(AAPL[1:100])
barChart(AAPL[1:100],theme="white")
candleChart(AAPL[1:100])
candleChart(AAPL[1:100],theme="white")
lineChart(AAPL[1:100])
lineChart(AAPL[1:100],theme="white")

lineChart(AAPL[1:100],theme="white")
addADX()
addBBands()
addDEMA()
addMACD()
addROC()
addRSI()
addSAR()

getSymbols("YHOO")
chartSeries(YHOO,TA=c(addVo(),addBBands()),theme="white")

YHOO.op<-Op(YHOO) ## Extract (transformed) data from a suitable OHLC object. 
head(YHOO.op)
is.OHLC(YHOO)
has.OHLC(YHOO)
has.Ad(YHOO) ## if there's adjusted data in YHOO
seriesHi(YHOO)
seriesHi(YHOO)

OpCl(YHOO)
OpOp(YHOO)
HiCl(YHOO)

first(YHOO)
first(YHOO,6)
first(YHOO,'2 weeks')
first(YHOO,'-2 weeks')

data = data.frame(Op(YHOO),
                  Lag(Op(YHOO)),
                  Next(Op(YHOO)),
                  Delt(Op(YHOO)))
head(data)

YHOO['2008']
YHOO['2008-01']
YHOO['2008-01::2009-02-12']
YHOO[c('2008-01','2009-01')]
